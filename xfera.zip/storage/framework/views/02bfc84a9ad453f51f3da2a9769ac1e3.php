<!-- Libs JS -->
<script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/simplebar/js/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/headhesive/js/headhesive.min.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/jarallax/dist/jarallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendors/jarallax.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/parallax-js/dist/parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendors/parallax.js')); ?>"></script>

<!-- Swiper JS -->
<script src="<?php echo e(asset('vendor/swiper/js/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendors/swiper.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendors/glight.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/scrollcue/js/scrollCue.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendors/scrollcue.js')); ?>"></script>

<!-- Theme JS -->
<!-- build:js js/theme.min.js -->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendors/offcanvas.js')); ?>"></script>
<!-- endbuild -->
<?php /**PATH D:\Disco Local C\TSM Web Developer\XFERA TECH\xfera\resources\views/partials/scripts.blade.php ENDPATH**/ ?>