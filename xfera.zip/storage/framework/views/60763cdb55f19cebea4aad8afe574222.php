<?php $__env->startSection('content'); ?>
    <main>
        <section id="home">
            <?php echo $__env->make('components.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </section>

        <section id="clients">
            
        </section>

        <section id="products">
            <?php echo $__env->make('components.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </section>
        <section id="about">
            <?php echo $__env->make('components.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </section>

        <section id="for-you">
            <?php echo $__env->make('components.for-you', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </section>

        <section id="how-to">
            <?php echo $__env->make('components.how-to', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </section>

        <section id="testimonials">

        </section>

        <section id="contact">
            <?php echo $__env->make('components.contato', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </section>

        <section id="community">
            <?php echo $__env->make('components.community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </section>

        <section id="explore">
            <?php echo $__env->make('components.explore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Disco Local C\TSM Web Developer\XFERA TECH\xfera\resources\views/index.blade.php ENDPATH**/ ?>