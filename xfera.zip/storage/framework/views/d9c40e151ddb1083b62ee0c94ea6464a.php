<!-- Favicon icon-->
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('images/favicon/apple-touch-icon.png')); ?>" />
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/favicon/favicon-32x32.png')); ?>" />
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon/favicon-16x16.png')); ?>" />
<link rel="manifest" href="<?php echo e(asset('images/favicon/site.webmanifest')); ?>" />
<link rel="mask-icon" href="<?php echo e(asset('images/favicon/block-safari-pinned-tab.svg')); ?>" color="#8b3dff" />
<link rel="shortcut icon" href="<?php echo e(asset('images/favicon/favicon.ico')); ?>" />
<meta name="msapplication-TileColor" content="#8b3dff" />
<meta name="msapplication-config" content="<?php echo e(asset('images/favicon/tile.xml')); ?>" />

<!-- Color modes -->
<script src="<?php echo e(asset('js/vendors/color-modes.js')); ?>"></script>

<!-- Libs CSS -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/swiper/css/swiper-bundle.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/glightbox/css/glightbox.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/simplebar/css/simplebar.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-icons/font/bootstrap-icons.css')); ?>">

<!-- Font Awesome -->
<script src="https://kit.fontawesome.com/4d3192896f.js" crossorigin="anonymous"></script>

<!-- Scroll Cue -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/scrollcue/css/scrollCue.css')); ?>">

<!-- Box icons -->
<link rel="stylesheet" href="<?php echo e(asset('fonts/css/boxicons.min.css')); ?>" />

<!-- Theme CSS -->
<!-- build:css css/theme.min.css -->
<link rel="stylesheet" href="<?php echo e(asset('css/theme.css')); ?>" />
<!-- endbuild -->
<?php /**PATH D:\Disco Local C\TSM Web Developer\XFERA TECH\xfera\resources\views/partials/head-links.blade.php ENDPATH**/ ?>