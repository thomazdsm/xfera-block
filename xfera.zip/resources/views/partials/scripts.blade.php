<!-- Libs JS -->
<script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('vendor/simplebar/js/simplebar.min.js') }}"></script>
<script src="{{ asset('vendor/headhesive/js/headhesive.min.js') }}"></script>

<script src="{{ asset('vendor/jarallax/dist/jarallax.min.js') }}"></script>
<script src="{{ asset('js/vendors/jarallax.js') }}"></script>
<script src="{{ asset('vendor/parallax-js/dist/parallax.min.js') }}"></script>
<script src="{{ asset('js/vendors/parallax.js') }}"></script>

<!-- Swiper JS -->
<script src="{{ asset('vendor/swiper/js/swiper-bundle.min.js') }}"></script>
<script src="{{ asset('js/vendors/swiper.js') }}"></script>
<script src="{{ asset('vendor/glightbox/js/glightbox.min.js') }}"></script>
<script src="{{ asset('js/vendors/glight.js') }}"></script>

<script src="{{ asset('vendor/scrollcue/js/scrollCue.min.js') }}"></script>
<script src="{{ asset('js/vendors/scrollcue.js') }}"></script>

<!-- Theme JS -->
<!-- build:js js/theme.min.js -->
<script src="{{ asset('js/main.js') }}"></script>
<script src="{{ asset('js/vendors/offcanvas.js') }}"></script>
<!-- endbuild -->
